package processor.pipeline;

import generic.Simulator;
import generic.Statistics;
import processor.Processor;

public class RegisterWrite {
	Processor containingProcessor;
	MA_RW_LatchType MA_RW_Latch;
	IF_EnableLatchType IF_EnableLatch;

	int instruction = 0, ldResult, aluResult, rd;
	String opcode;
	
	public int getInstrucion()
	{
		return instruction;
	}
	
	public RegisterWrite(Processor containingProcessor, MA_RW_LatchType mA_RW_Latch, IF_EnableLatchType iF_EnableLatch)
	{
		this.containingProcessor = containingProcessor;
		this.MA_RW_Latch = mA_RW_Latch;
		this.IF_EnableLatch = iF_EnableLatch;
	}
	
	private boolean isWriteNeeded()
	{
		if (opcode.equals("11000") ||
			opcode.equals("11001") || 
			opcode.equals("11010") ||
			opcode.equals("11011") ||
			opcode.equals("11100") ||
			opcode.equals("10111")) return false;
		return true;
	}
	
	public void performRW()
	{
		
		if(MA_RW_Latch.isRW_enable())
		{
			//MA stage has given some work to do;
			
			// checking if it is needed to write ot not:
			// if instruction being processed is an end instruction, remember to call Simulator.setSimulationComplete(true);
			opcode = MA_RW_Latch.getOpcode();
			instruction = MA_RW_Latch.getInstruction();
			aluResult = MA_RW_Latch.getAluResult();
			ldResult = MA_RW_Latch.getLdResult();
			
			if(isWriteNeeded())
			{
				String instructionBits = Integer.toBinaryString(instruction);
				while(instructionBits.length() < 32)
					instructionBits = "0" + instructionBits;
				
				if (ControlUnit.isImmediate(opcode))
				{
					String rd_bin = instructionBits.substring(10,15);
					rd = Integer.parseInt(rd_bin,2); 						// rd cant be -ve
					
					if (ControlUnit.isLd(opcode))
						containingProcessor.getRegisterFile().setValue(rd, ldResult);
					else
						containingProcessor.getRegisterFile().setValue(rd, aluResult);
				}
				else
				{
					String rd_bin = instructionBits.substring(15,20);
					rd = Integer.parseInt(rd_bin,2);
					containingProcessor.getRegisterFile().setValue(rd, aluResult);
				}
			}
			// checking for the end instruction:
			if(opcode.equals("11101"))
			{
				Simulator.setSimulationComplete(true);
				// to neutralise the affect of end on program counter: subtract 4 
				// just to match the output given by Sir add 1;
				int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
				containingProcessor.getRegisterFile().setProgramCounter(currentPC+1);
			}
			// updating the number of instructions;
			Statistics.updateInstruction();
		}
		else					// no work from the MA stage.
			instruction = 0;
	}

}
