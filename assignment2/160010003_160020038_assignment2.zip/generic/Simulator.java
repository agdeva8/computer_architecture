package generic;

import java.io.*;
import java.nio.ByteBuffer;

import generic.Instruction.OperationType;
import generic.Operand.OperandType;


public class Simulator {
		
	static FileInputStream inputcodeStream = null;
	
	public static void setupSimulation(String assemblyProgramFile, String objectProgramFile)
	{	
		int firstCodeAddress = ParsedProgram.parseDataSection(assemblyProgramFile);
		ParsedProgram.parseCodeSection(assemblyProgramFile, firstCodeAddress);
		ParsedProgram.printState();
	}
	
	public static String fixLength5(int number) {
		return String.format("%5s", Integer.toBinaryString(number)).replace(' ', '0');
	}
	
	public static String fixLength12(int number) {
		return String.format("%12s", Integer.toBinaryString(number)).replace(' ', '0');
	}
	
	public static String fixLength17(int number) {
		if(number>=0)
			return String.format("%17s", Integer.toBinaryString(number)).replace(' ', '0');
		else
			return String.format("%17s", Integer.toBinaryString(number)).replace(' ', '0').substring(15);
	}
	
	public static String fixLength22(int number) {
		if(number>=0)
			return String.format("%22s", Integer.toBinaryString(number)).replace(' ', '0');
		else
			return String.format("%22s", Integer.toBinaryString(number)).replace(' ', '0').substring(10);
	}
	
	public static void assemble(String objectProgramFile)
	{
	
		File file = new File(objectProgramFile);
        file.delete();
		
		FileOutputStream fos;
		
		int start=ParsedProgram.firstCodeAddress;
		int end=(ParsedProgram.firstCodeAddress+ParsedProgram.code.size()-1);
		
		int mainPos = ParsedProgram.mainFunctionAddress;
		
		try {
			fos = new FileOutputStream(objectProgramFile,true);
			DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
			outStream.writeInt(mainPos);
			outStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int i;
		
		for(i=0; i<start; i++) {
			int onedata = ParsedProgram.data.get(i);
			System.out.println("writing "+onedata);
			try {
				fos = new FileOutputStream(objectProgramFile,true);
				DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
				outStream.writeInt(onedata);
				outStream.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		for(i=start; i<=end; i++) {
			
			Instruction line = ParsedProgram.getInstructionAt(i);
		
			int rs1, rs2, rd;
			String opcode, rs1Bin, rs2Bin, rdBin, unused12, command;
			
			unused12 = fixLength12(0);
			
			switch(line.getOperationType()) {
				
				case add:
					System.out.println("add!");
					opcode = "00000";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();					
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rs2Bin+" "+rdBin+" "+unused12);
					command = opcode+rs1Bin+rs2Bin+rdBin+unused12;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case addi:
					System.out.println("addi!");
					opcode = "00001";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rdBin+" "+rs2Bin);
					command = opcode+rs1Bin+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case sub:
					System.out.println("sub!");
					opcode = "00010";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rs2Bin+" "+rdBin+" "+unused12);
					command = opcode+rs1Bin+rs2Bin+rdBin+unused12;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case subi:
					System.out.println("subi!");
					opcode = "00011";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rdBin+" "+rs2Bin);
					command = opcode+rs1Bin+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case mul:
					System.out.println("mul!");
					opcode = "000100";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rs2Bin+" "+rdBin+" "+unused12);
					command = opcode+rs1Bin+rs2Bin+rdBin+unused12;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case muli:
					System.out.println("muli!");
					opcode = "00101";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rdBin+" "+rs2Bin);
					command = opcode+rs1Bin+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case div:
					System.out.println("div!");
					opcode = "000110";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rs2Bin+" "+rdBin+" "+unused12);
					command = opcode+rs1Bin+rs2Bin+rdBin+unused12;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case divi:
					System.out.println("divi!");
					opcode = "00111";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rdBin+" "+rs2Bin);
					command = opcode+rs1Bin+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case and:
					System.out.println("and!");
					opcode = "01000";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rs2Bin+" "+rdBin+" "+unused12);
					command = opcode+rs1Bin+rs2Bin+rdBin+unused12;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}				
					break;
				case andi:
					System.out.println("andi!");
					opcode = "01001";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rdBin+" "+rs2Bin);
					command = opcode+rs1Bin+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case or:
					System.out.println("or!");
					opcode = "01010";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rs2Bin+" "+rdBin+" "+unused12);
					command = opcode+rs1Bin+rs2Bin+rdBin+unused12;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case ori:
					System.out.println("ori!");
					opcode = "01011";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rdBin+" "+rs2Bin);
					command = opcode+rs1Bin+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case xor:
					System.out.println("xor!");
					opcode = "01100";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rs2Bin+" "+rdBin+" "+unused12);
					command = opcode+rs1Bin+rs2Bin+rdBin+unused12;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case xori:
					System.out.println("xori!");
					opcode = "01101";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rdBin+" "+rs2Bin);
					command = opcode+rs1Bin+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case slt:
					System.out.println("slt!");
					opcode = "01110";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rs2Bin+" "+rdBin+" "+unused12);
					command = opcode+rs1Bin+rs2Bin+rdBin+unused12;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case slti:
					System.out.println("slti!");
					opcode = "01111";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rdBin+" "+rs2Bin);
					command = opcode+rs1Bin+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case sll:
					System.out.println("sll!");
					opcode = "10000";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rs2Bin+" "+rdBin+" "+unused12);
					command = opcode+rs1Bin+rs2Bin+rdBin+unused12;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case slli:
					System.out.println("slli!");
					opcode = "10001";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rdBin+" "+rs2Bin);
					command = opcode+rs1Bin+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case srl:
					System.out.println("srl!");
					opcode = "10010";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rs2Bin+" "+rdBin+" "+unused12);
					command = opcode+rs1Bin+rs2Bin+rdBin+unused12;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case srli:
					System.out.println("srli!");
					opcode = "10011";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rdBin+" "+rs2Bin);
					command = opcode+rs1Bin+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case sra:
					System.out.println("sra!");
					opcode = "10100";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rs2Bin+" "+rdBin+" "+unused12);
					command = opcode+rs1Bin+rs2Bin+rdBin+unused12;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case srai:
					System.out.println("srai!");
					opcode = "10101";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rdBin+" "+rs2Bin);
					command = opcode+rs1Bin+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case load:
					System.out.println("load!");
					opcode = "10110";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rdBin+" "+rs2Bin);
					command = opcode+rs1Bin+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case store:
					System.out.println("store!");
					opcode = "10111";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength17(rs2);
					rdBin = fixLength5(rd);
					System.out.println(opcode+" "+rs1Bin+" "+rdBin+" "+rs2Bin);
					command = opcode+rs1Bin+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case jmp:
					System.out.println("jmp!");
					opcode = "11000";
//					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
//					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
//					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue() - ParsedProgram.getInstructionAt(i).getProgramCounter();
					
					System.out.println(ParsedProgram.getInstructionAt(i).getDestinationOperand().getOperandType());
					
					switch (ParsedProgram.getInstructionAt(i).getDestinationOperand().getOperandType()) {
					case Immediate:
						rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
						rdBin = fixLength22(rd);
						command = opcode + "00000" + rdBin;
						try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						break;
					case Label:
						String labelname = ParsedProgram.getInstructionAt(i).getDestinationOperand().labelValue;
						int position = ParsedProgram.symtab.get(labelname) - ParsedProgram.getInstructionAt(i).getProgramCounter();
						rd = position;
						rdBin = fixLength22(rd);
						command = opcode + "00000" + rdBin;
						try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						break;
					case Register:
						rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
						rdBin = fixLength5(rd);
						command = opcode + rdBin + fixLength22(0);
						try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						break;
					}
					break;
				case beq:
					System.out.println("beq!");
					opcode = "11001";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					
					switch (ParsedProgram.getInstructionAt(i).getDestinationOperand().getOperandType()){
						case Label:
							String labelname = ParsedProgram.getInstructionAt(i).getDestinationOperand().labelValue;
							int position = ParsedProgram.symtab.get(labelname) - ParsedProgram.getInstructionAt(i).getProgramCounter();
							rd = position;
							rdBin = fixLength17(rd);
							command = opcode + rs1Bin + rs2Bin + rdBin;
							try {
							fos = new FileOutputStream(objectProgramFile,true);
							DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
							int comm_intval = (int) Long.parseLong(command,2);
							outStream.writeInt(comm_intval);
							outStream.close();
							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							break;
						case Immediate:
							rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
							rdBin = fixLength17(rd);
							command = opcode + rs1Bin + rs2Bin + rdBin;
							try {
							fos = new FileOutputStream(objectProgramFile,true);
							DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
							int comm_intval = (int) Long.parseLong(command,2);
							outStream.writeInt(comm_intval);
							outStream.close();
							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							break;
					}
					break;
				case bne:
					System.out.println("bne!");
					opcode = "11010";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					
					switch (ParsedProgram.getInstructionAt(i).getDestinationOperand().getOperandType()){
						case Label:
							String labelname = ParsedProgram.getInstructionAt(i).getDestinationOperand().labelValue;
							int position = ParsedProgram.symtab.get(labelname) - ParsedProgram.getInstructionAt(i).getProgramCounter();
							rd = position;
							rdBin = fixLength17(rd);
							command = opcode + rs1Bin + rs2Bin + rdBin;
							try {
							fos = new FileOutputStream(objectProgramFile,true);
							DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
							int comm_intval = (int) Long.parseLong(command,2);
							outStream.writeInt(comm_intval);
							outStream.close();
							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							break;
						case Immediate:
							rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
							rdBin = fixLength17(rd);
							command = opcode + rs1Bin + rs2Bin + rdBin;
							try {
							fos = new FileOutputStream(objectProgramFile,true);
							DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
							int comm_intval = (int) Long.parseLong(command,2);
							outStream.writeInt(comm_intval);
							outStream.close();
							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							break;
					}
					break;
				case blt:
					System.out.println("blt!");
					opcode = "11011";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					
					switch (ParsedProgram.getInstructionAt(i).getDestinationOperand().getOperandType()){
						case Label:
							String labelname = ParsedProgram.getInstructionAt(i).getDestinationOperand().labelValue;
							int position = ParsedProgram.symtab.get(labelname) - ParsedProgram.getInstructionAt(i).getProgramCounter();
							rd = position;
							rdBin = fixLength17(rd);
							command = opcode + rs1Bin + rs2Bin + rdBin;
							try {
							fos = new FileOutputStream(objectProgramFile,true);
							DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
							int comm_intval = (int) Long.parseLong(command,2);
							outStream.writeInt(comm_intval);
							outStream.close();
							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							break;
						case Immediate:
							rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
							rdBin = fixLength17(rd);
							command = opcode + rs1Bin + rs2Bin + rdBin;
							try {
							fos = new FileOutputStream(objectProgramFile,true);
							DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
							int comm_intval = (int) Long.parseLong(command,2);
							outStream.writeInt(comm_intval);
							outStream.close();
							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							break;
					}
					break;
				case bgt:
					System.out.println("bgt!");
					opcode = "11100";
					rs1 = ParsedProgram.getInstructionAt(i).getSourceOperand1().getValue();
					rs2 = ParsedProgram.getInstructionAt(i).getSourceOperand2().getValue();
					rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
					rs1Bin = fixLength5(rs1);
					rs2Bin = fixLength5(rs2);
					
					switch (ParsedProgram.getInstructionAt(i).getDestinationOperand().getOperandType()){
						case Label:
							String labelname = ParsedProgram.getInstructionAt(i).getDestinationOperand().labelValue;
							int position = ParsedProgram.symtab.get(labelname) - ParsedProgram.getInstructionAt(i).getProgramCounter();
							rd = position;
							rdBin = fixLength17(rd);
							command = opcode + rs1Bin + rs2Bin + rdBin;
							try {
							fos = new FileOutputStream(objectProgramFile,true);
							DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
							int comm_intval = (int) Long.parseLong(command,2);
							outStream.writeInt(comm_intval);
							outStream.close();
							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							break;
						case Immediate:
							rd = ParsedProgram.getInstructionAt(i).getDestinationOperand().getValue();
							rdBin = fixLength17(rd);
							command = opcode + rs1Bin + rs2Bin + rdBin;
							try {
							fos = new FileOutputStream(objectProgramFile,true);
							DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
							int comm_intval = (int) Long.parseLong(command,2);
							outStream.writeInt(comm_intval);
							outStream.close();
							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							break;
					}
					break;
				case end:
					System.out.println("end!");
					opcode = "11101";
					rdBin = fixLength5(0);
					rs2Bin = fixLength22(0);
					System.out.println(opcode+" "+rdBin+" "+rs2Bin);
					command = opcode+rdBin+rs2Bin;
					try {
						fos = new FileOutputStream(objectProgramFile,true);
						DataOutputStream outStream = new DataOutputStream(new BufferedOutputStream(fos));
						int comm_intval = (int) Long.parseLong(command,2);
						outStream.writeInt(comm_intval);
						outStream.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
					
					
			}
		}
	}
	
}
