package generic;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Simulator {
		
	static FileInputStream inputcodeStream = null;
	static String of;
	
	public static void setupSimulation(String assemblyProgramFile, String objectProgramFile)
	{	
		int firstCodeAddress = ParsedProgram.parseDataSection(assemblyProgramFile);
		ParsedProgram.parseCodeSection(assemblyProgramFile, firstCodeAddress);
		ParsedProgram.printState();
		of=objectProgramFile;
	}
	
	public static void assemble() throws IOException
	{
		DataOutputStream dos =new DataOutputStream(new FileOutputStream(of));
		//Types of instructions
		int[] r3= {0,2,4,6,8,10,12,14,16,18,20};
		int[] r2i={1,3,5,7,9,11,13,15,17,19,21,22,23};
		int[] r2il= {25,26,27,28};
		int[] ri= {24,29};
		
		int mainAddr=ParsedProgram.mainFunctionAddress;//MainFunctionAddress
		dos.writeInt(mainAddr);//Writing MainFunctionAddress
		
		for(int d: ParsedProgram.data)
			dos.writeInt(d);//Writing datas in outputFile
		for(Instruction ist : ParsedProgram.code)
		{
			int operationIndex=ist.getOperationType().ordinal();//Getting Index of operation
			String str="";//Initialising the binary string
			
			for(int oi:r3)//all of type r3
			{
				if(operationIndex==oi)//if operation matches
				{
					String boi=Integer.toBinaryString(operationIndex);//OPCODE OF Operation
					str=boi;
					while(str.length()!=5)//length 5
					str="0"+str;
					String rs1=Integer.toBinaryString(ist.getSourceOperand1().getValue());
					while(rs1.length()!=5)
					rs1="0"+rs1;
					str=str.concat(rs1);
					String rs2=Integer.toBinaryString(ist.getSourceOperand2().getValue());
					while(rs2.length()!=5)
					rs2="0"+rs2;
					str=str.concat(rs2);
					String rd=Integer.toBinaryString(ist.getDestinationOperand().getValue());
					while(rd.length()!=5)
					rd="0"+rd;
					str=str.concat(rd);
					str=str+"000000000000"; //last unused bits
				}
			}
			
			for(int oi:r2i)//operation of type r2i
			{
				if(operationIndex==oi)
				{
					String boi=Integer.toBinaryString(operationIndex);
					str=boi;
					while(str.length()!=5)
					str="0"+str;
					String rs1=Integer.toBinaryString(ist.getSourceOperand1().getValue());
					while(rs1.length()!=5)
					rs1="0"+rs1;
					str=str.concat(rs1);
					String rd=Integer.toBinaryString(ist.getDestinationOperand().getValue());
					while(rd.length()!=5)
					rd="0"+rd;
					str=str.concat(rd);
					String imm=Integer.toBinaryString(ist.getSourceOperand2().getValue());
					while(imm.length()!=17)
					imm="0"+imm;
					str=str.concat(imm);
				}
			}
			
			for(int oi:r2il)//Operations of type r2i having labels
			{
				if(operationIndex==oi)
				{
					String boi=Integer.toBinaryString(operationIndex);
					str=boi;
					while(str.length()!=5)
					str="0"+str;
					String rs1=Integer.toBinaryString(ist.getSourceOperand1().getValue());
					while(rs1.length()!=5)
					rs1="0"+rs1;
					str=str.concat(rs1);
					String rd=Integer.toBinaryString(ist.getSourceOperand2().getValue());
					while(rd.length()!=5)
					rd="0"+rd;
					str=str.concat(rd);
					int PC=ist.getProgramCounter();
					int labelAt=ParsedProgram.symtab.get(ist.getDestinationOperand().getLabelValue());
					int diff=labelAt-PC;
					int ndiff;
					if(diff<0) ndiff=diff*-1;
					else ndiff=diff;
					String imm=Integer.toBinaryString(ndiff);
					while(imm.length()!=17)
					imm="0"+imm;
					if(diff<0)
						imm=getComplement(imm);//calculating complement
					str=str+imm;
				}
			}
			
			for(int oi:ri)//Operations of type ri
			{
				if(operationIndex==oi)
				{
					String boi=Integer.toBinaryString(operationIndex);
					str=boi;
					while(str.length()!=5)
					str="0"+str;
					String rd="00000";
					str=str.concat(rd);
					if(operationIndex==24)//Jump operation
					{
						int PC=ist.getProgramCounter();
						int labelAt=ParsedProgram.symtab.get(ist.getDestinationOperand().getLabelValue());
						int diff=labelAt-PC;
						int ndiff;
						if(diff<0) ndiff=diff*-1;
						else 
							ndiff=diff;
						String imm=Integer.toBinaryString(ndiff);
						while(imm.length()!=22)
						imm="0"+imm;
						if(diff<0)
							imm=getComplement(imm);
						str=str+imm;
					}
					else if(operationIndex==29)//End operation
					{
						String imm="";
						while(imm.length()!=22)
						imm="0"+imm;
						str=str.concat(imm);
					}
				}
			}
			int instcode=Integer.parseUnsignedInt(str, 2);//Converting binary code to integer
			dos.writeInt(instcode); //Writing iinteger in binary file
		}
	}
	
	static String getComplement(String s)//Function to calculate complement
	{
		String str="";
		for (int i=0;i<s.length();i++)
		{
			if(s.charAt(i)=='0')
				str=str+"1";
			else
				str=str+"0";
		}
		int num=Integer.parseUnsignedInt(str,2);
		num++;
		str=Integer.toBinaryString(num);
		return str;
	}
}
